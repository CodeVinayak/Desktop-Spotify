# Note for contributors
Anyone is welcome to contribute to the project.
- If you are working on an issue, or want to add your own cool feature make sure you *create and issue* with one of the issue templates provides [here](https://github.com/jessej-samuel/spotipy/tree/master/.github/ISSUE_TEMPLATE).
- After that please wait for a maintainer to approve and assign the issue to you.
- Then, you can fork the repo and start working on the issue. We request that all contributors try to fix their issues within 7 days.
- In case, more time is required, you can state your request in advance to the maintainer.
- If there is no activity, then the issue will be unassigned and made open again.
